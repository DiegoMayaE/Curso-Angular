 /*
    ===== Código de TypeScript =====
*/
class  PersonaNormal{
    constructor(
        public nombre: string,
        public direccion: string
    ){}
}
class Heroe extends PersonaNormal{
   
    constructor(
    public alerEgo: string,
    public edad: number,
    public nombreReal: string
    ){
        super(nombreReal,'NY USA');
    }
    
}
const iroman = new Heroe('Iroman', 45, 'Tony');
console.log(iroman);

// -------- codigos independientes uno de otro ---------
// Version del CONSTRUCTOR
/*class Heroe{
    //alterEgo: string;
    //edad: number;
    //nombreReal: number;
   constructor(
    public alerEgo: string,
    public edad: number,
    public nombreReal: string
    ){}
}
const iroman = new Heroe('Iroman', 45, 'Tony');
console.log(iroman);*/

// Version de PRIVATE
/*class Heroe{
    private alterEgo: string;
    public edad: number;
    static nombreReal: number;
    constructor(){
        this.alterEgo;
        this.edad;
    }
}*/

// Version de PUBLIC
/*class Heroe{
    private alterEgo: string;
    public edad: number;
    static nombreReal: number;
}
const iroman =new Heroe();
iroman.edad;*/

// Version de STATIC
/*class Heroe{
    private alterEgo: string;
    public edad: number;
    static nombreReal: number;
}
Heroe.nombreReal;*/