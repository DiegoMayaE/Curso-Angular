 /*
    ===== Código de TypeScript =====
*/
interface Reproductor{
    volumen: number,
    segundo: number,
    cancion: string,
    detalles: Detalles
}
interface Detalles{
    autor: string,
    anio: number,
}
const reproductor: Reproductor={
    volumen: 90,
    segundo: 36,
    cancion: 'Mess',
    detalles:{
        autor:'Ed Sherman',
        anio: 2015,
    }
}
// Desestructuracion 
//ALTERNATIVA 1 mas recomendable por visualizacion 
const{volumen, segundo,cancion, detalles}=reproductor;
const{autor}=detalles;
console.log('El volumen actual es: ', volumen );
console.log('El segundo actual es: ', segundo);
console.log('La cancion actual es: ', cancion);
console.log('El autor es: ',  autor);

 
/*ALTERNATIVA 2
const{volumen, segundo,cancion, detalles:{autor}}=reproductor;
console.log('El volumen actual es: ', volumen );
console.log('El segundo actual es: ', segundo);
console.log('La cancion actual es: ', cancion);
console.log('El autor es: ',  autor);
*/

// codigo robust, no recomendable
/* 
 console.log('El volumen actual es: ', reproductor.volumen );
 console.log('El segundo actual es: ', reproductor.segundo);
 console.log('La cancion actual es: ', reproductor.cancion);
 console.log('El autor es: ', reproductor.detalles.autor);
 */


 const pokemon: string [] = ['Pikachu', 'Bulbasaur', 'Squirtle','Charmander'];
 //alternativa
 const [p1,p2,p3,p4] = pokemon;
 console.log('Personaje 0: ', p1);
 console.log('Personaje 1: ', p2);
 console.log('Personaje 2: ', p3);
 console.log('Personaje 3: ', p4);


 /* Codigo robusto
 console.log('Personaje 0: ', pokemon[0]);
 console.log('Personaje 1: ', pokemon[1]);
 console.log('Personaje 2: ', pokemon[2]);
 console.log('Personaje 3: ', pokemon[3]);
*/