 /*
    ===== Código de TypeScript =====
*/
let habilidades: string[] = ['bash', 'counter', 'healing'];

interface Personaje{
    nomre: string,
    hp: number,
    habilidades: string[],
    puebloNatal?: string
}
const personaje: Personaje ={
    nomre: 'Diego',
    hp: 100,
    habilidades: ['bash', 'counter', 'healing']
}

personaje.puebloNatal='Xochimilco';

console.table(personaje);