 /*
    ===== Código de TypeScript =====
*/
function sumar(a:number,b:number): number {
    return a + b;
}

const sumarFlecha = (a:number,b:number): number=>{
    return a + b;
}

function multiplicar( numero: number, otronumero?:number, base:number = 2):number{
    return numero * base;
}

interface PersonajeCur{
    nombre: string;
    pv: number;
    mostrarpv:()=>void;
}

function curar(personaje: PersonajeCur, curarX:number ):void{
    personaje.pv += curarX;
    console.log(personaje);
    
}
const newpersonaje: PersonajeCur={
    nombre: 'Diego',
    pv: 30,
    mostrarpv(){
        console.log('puntos de vida' , this.pv);
    }
}
curar(newpersonaje,20);
newpersonaje.mostrarpv();
//const resultado = multiplicar(15,0, 2);

//console.log(resultado);