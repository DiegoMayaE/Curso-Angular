 /*
    ===== Código de TypeScript =====
*/
let nombre : string = 'Diego'; 
 nombre= 'jackeline'
let hp: number | string = 95;
let estaVivo: boolean = true;

 
 console.log(nombre,hp)