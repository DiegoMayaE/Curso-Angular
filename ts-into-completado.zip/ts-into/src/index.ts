 /*
    ===== Código de TypeScript =====
*/
